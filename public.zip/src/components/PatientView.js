import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
// import { User } from 'lucide-react';

const PatientProfile = () => {
  const [scores, setScores] = useState({
    medication: 5,
    diet: 5,
    exercise: 5
  });
  const [showSuccess, setShowSuccess] = useState(false);

  // Sample data - replace with actual data from your database
  const healthData = [
    { date: '2024-01-01', medicine: 7, diet: 6, exercise: 8 },
    { date: '2024-01-02', medicine: 8, diet: 7, exercise: 6 },
    { date: '2024-01-03', medicine: 6, diet: 8, exercise: 7 },
    { date: '2024-01-04', medicine: 9, diet: 7, exercise: 8 },
    { date: '2024-01-05', medicine: 7, diet: 8, exercise: 9 }
  ];

  const handleScoreChange = (type, value) => {
    setScores(prev => ({ ...prev, [type]: value }));
  };

  const handleSubmit = () => {
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 space-y-6">
      {/* Patient Header */}
      <div className="flex items-center space-x-4 bg-green-50 p-4 rounded-lg">
        {/* <User size={48} className="text-green-600" /> */}
        <div>
          <h1 className="text-2xl font-bold text-green-800">John Doe</h1>
          <p className="text-green-600">Patient ID: 12345</p>
        </div>
      </div>

      {/* Health Progress Graph */}
      <div className="bg-white shadow-md rounded-lg p-4">
        <h2 className="text-xl font-semibold mb-4">Health Progress</h2>
        <div className="h-64 w-full">
          <ResponsiveContainer>
            <LineChart data={healthData}>
              <XAxis dataKey="date" />
              <YAxis domain={[0, 10]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="medicine" stroke="#ff0000" name="Medication" />
              <Line type="monotone" dataKey="diet" stroke="#00ff00" name="Diet" />
              <Line type="monotone" dataKey="exercise" stroke="#0000ff" name="Exercise" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Self Scoring Section */}
      <div className="bg-white shadow-md rounded-lg p-4 space-y-6">
        <h2 className="text-xl font-semibold mb-4">Daily Health Score</h2>

        {/* Medication Score */}
        <div>
          <label className="block text-sm font-medium mb-2">Medication Score</label>
          <input
            type="range"
            min="1"
            max="10"
            value={scores.medication}
            onChange={(e) => handleScoreChange('medication', parseInt(e.target.value))}
            className="w-full"
          />
          <div className="text-right">{scores.medication}/10</div>
        </div>

        {/* Diet Score */}
        <div>
          <label className="block text-sm font-medium mb-2">Diet Score</label>
          <input
            type="range"
            min="1"
            max="10"
            value={scores.diet}
            onChange={(e) => handleScoreChange('diet', parseInt(e.target.value))}
            className="w-full"
          />
          <div className="text-right">{scores.diet}/10</div>
        </div>

        {/* Exercise Score */}
        <div>
          <label className="block text-sm font-medium mb-2">Exercise Score</label>
          <input
            type="range"
            min="1"
            max="10"
            value={scores.exercise}
            onChange={(e) => handleScoreChange('exercise', parseInt(e.target.value))}
            className="w-full"
          />
          <div className="text-right">{scores.exercise}/10</div>
        </div>

        <button 
          onClick={handleSubmit}
          className="w-full bg-green-600 text-white py-2 px-4 rounded hover:bg-green-700"
        >
          Submit Daily Scores
        </button>
      </div>

      {/* Success Message */}
      {showSuccess && (
        <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
          <p className="text-green-800">Scores submitted successfully!</p>
        </div>
      )}
    </div>
  );
};

export default PatientProfile;
