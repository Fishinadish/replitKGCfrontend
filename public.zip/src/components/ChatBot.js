// KeepGoingCare.js
import React, { useState } from 'react';

const KeepGoingCare = () => {
  const [messages, setMessages] = useState([
    { sender: 'bot', text: 'Welcome to Keep Going Care! How can I assist you today?' }
  ]);
  const [userMessage, setUserMessage] = useState('');

  const handleSendMessage = () => {
    if (userMessage.trim()) {
      // Add user message to chat
      setMessages([...messages, { sender: 'user', text: userMessage }]);

      // Simulate bot response
      setTimeout(() => {
        setMessages((prevMessages) => [
          ...prevMessages,
          { sender: 'bot', text: `You said: ${userMessage}` }
        ]);
      }, 1000);

      // Clear input field
      setUserMessage('');
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      {/* Title */}
      <header className="p-4 bg-green-600 text-white text-center shadow-lg">
        <h2 className="text-3xl font-bold">Keep Going Care</h2>
      </header>

      {/* Chat Display */}
      <div className="flex-grow p-6 overflow-y-auto">
        <div className="space-y-4 max-w-2xl mx-auto">
          {messages.map((message, index) => (
            <div
              key={index}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`${
                  message.sender === 'user' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-800'
                } p-3 rounded-lg max-w-xs`}
              >
                {message.text}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Input Field */}
      <div className="p-4 bg-white border-t border-gray-200">
        <div className="flex items-center max-w-2xl mx-auto space-x-4">
          <input
            type="text"
            value={userMessage}
            onChange={(e) => setUserMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
          />
          <button
            onClick={handleSendMessage}
            className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
};

export default KeepGoingCare;
