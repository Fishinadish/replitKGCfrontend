import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const DoctorDashboard = () => {
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [healthPoints, setHealthPoints] = useState({
    point1: '',
    point2: '',
    point3: ''
  });
  const [showSuccess, setShowSuccess] = useState(false);

  // Sample patient data
  const patients = [
    {
      id: 1,
      name: "John Doe",
      age: 45,
      lastVisit: "2024-01-15",
      condition: "Diabetes",
      healthData: [
        { date: '2024-01-01', medicine: 7, diet: 6, exercise: 8 },
        { date: '2024-01-02', medicine: 8, diet: 7, exercise: 6 },
        { date: '2024-01-03', medicine: 6, diet: 8, exercise: 7 },
        { date: '2024-01-04', medicine: 9, diet: 7, exercise: 8 },
        { date: '2024-01-05', medicine: 7, diet: 8, exercise: 9 }
      ]
    },
    {
      id: 2,
      name: "Jane Smith",
      age: 32,
      lastVisit: "2024-01-18",
      condition: "Hypertension",
      healthData: [
        { date: '2024-01-01', medicine: 6, diet: 7, exercise: 5 },
        { date: '2024-01-02', medicine: 7, diet: 8, exercise: 6 },
        { date: '2024-01-03', medicine: 8, diet: 6, exercise: 7 },
        { date: '2024-01-04', medicine: 7, diet: 7, exercise: 8 },
        { date: '2024-01-05', medicine: 8, diet: 8, exercise: 7 }
      ]
    }
  ];

  const handlePatientSelect = (patient) => {
    setSelectedPatient(patient);
    setHealthPoints({
      point1: '',
      point2: '',
      point3: ''
    });
  };

  const handleHealthPointChange = (field, value) => {
    setHealthPoints(prev => ({ ...prev, [field]: value }));
  };

  const handleSaveHealthPoints = () => {
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  // Patient List View
  const PatientListView = () => (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          <h1 className="text-2xl font-bold text-green-800">My Patients</h1>
        </div>
        <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center">
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
          Add New Patient
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {patients.map(patient => (
          <div 
            key={patient.id}
            className="border rounded-lg p-4 cursor-pointer hover:shadow-lg transition-shadow bg-white"
            onClick={() => handlePatientSelect(patient)}
          >
            <div className="flex items-center space-x-4">
              <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
              </svg>
              <div>
                <h3 className="font-semibold text-lg">{patient.name}</h3>
                <p className="text-sm text-gray-600">Age: {patient.age}</p>
                <p className="text-sm text-gray-600">Condition: {patient.condition}</p>
                <p className="text-sm text-green-600">Last Visit: {patient.lastVisit}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  // Detailed Patient View
  const PatientDetailView = () => (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between mb-6">
        <button 
          onClick={() => setSelectedPatient(null)}
          className="flex items-center text-green-600 hover:text-green-800"
        >
          <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          Back to Patient List
        </button>
        <div className="flex items-center space-x-4">
          <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
          <div>
            <h2 className="text-2xl font-bold text-green-800">{selectedPatient.name}</h2>
            <p className="text-green-600">Patient ID: {selectedPatient.id}</p>
          </div>
        </div>
      </div>

      <div className="border rounded-lg p-6 bg-white">
        <h3 className="text-xl font-semibold mb-4">Health Progress</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer>
            <LineChart data={selectedPatient.healthData}>
              <XAxis dataKey="date" />
              <YAxis domain={[0, 10]} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="medicine" stroke="#ef4444" name="Medication" />
              <Line type="monotone" dataKey="diet" stroke="#22c55e" name="Diet" />
              <Line type="monotone" dataKey="exercise" stroke="#3b82f6" name="Exercise" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="border rounded-lg p-6 bg-white">
        <h3 className="text-xl font-semibold mb-4">Major Health Points</h3>
        <div className="space-y-6">
          {[1, 2, 3].map((num) => (
            <div key={num} className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Health Point {num}
              </label>
              <textarea
                value={healthPoints[`point${num}`]}
                onChange={(e) => handleHealthPointChange(`point${num}`, e.target.value)}
                placeholder={`Enter major health point ${num} for the patient...`}
                className="w-full p-2 border rounded-md min-h-[80px] focus:ring-2 focus:ring-green-500 focus:border-green-500"
              />
            </div>
          ))}

          <button 
            onClick={handleSaveHealthPoints}
            className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center justify-center"
          >
            <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
            </svg>
            Save Health Points
          </button>
        </div>
      </div>

      {showSuccess && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <p className="text-green-800">Health points saved successfully!</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto">
      {selectedPatient ? <PatientDetailView /> : <PatientListView />}
    </div>
  );
};

export default DoctorDashboard;