// LandingPage.js
import React from 'react';
import { Link } from 'react-router-dom';

const LandingPage = () => {
  return (
    <div className="bg-gray-100 min-h-screen flex flex-col items-center text-center">
      {/* Header */}
      <header className="w-full bg-green-600 py-6 text-white shadow-lg">
        <h1 className="text-4xl font-bold">Welcome to Keep Going Care</h1>
        <p className="mt-2 text-lg">Your partner in achieving healthier lifestyle goals</p>
      </header>

      {/* Main Section */}
      <main className="flex-grow flex flex-col items-center px-6 py-12 space-y-12">
        {/* Intro Section */}
        <section className="max-w-4xl">
          <h2 className="text-3xl font-semibold text-green-800 mb-4">Personalized Health and Wellness Support</h2>
          <p className="text-gray-700 text-lg">
            Keep Going Care is a 24/7 virtual assistant designed to support you in achieving your health goals, in partnership with your healthcare provider. Through personalized meal plans, exercise routines, and medication reminders, we empower you to live a healthier, happier life.
          </p>
        </section>

        {/* Features Section */}
        <section className="flex flex-col md:flex-row space-y-8 md:space-y-0 md:space-x-8 max-w-4xl">
          {/* Feature Cards */}
          <div className="bg-white p-6 shadow-md rounded-lg w-full md:w-1/3">
            <h3 className="text-xl font-semibold text-green-800 mb-4">Diet and Nutrition</h3>
            <p className="text-gray-700">
              Tailored meal plans and assistance to help you build a healthier relationship with food.
            </p>
          </div>
          <div className="bg-white p-6 shadow-md rounded-lg w-full md:w-1/3">
            <h3 className="text-xl font-semibold text-green-800 mb-4">Exercise and Wellness</h3>
            <p className="text-gray-700">
              Customized fitness plans, videos, and gym recommendations to fit your lifestyle.
            </p>
          </div>
          <div className="bg-white p-6 shadow-md rounded-lg w-full md:w-1/3">
            <h3 className="text-xl font-semibold text-green-800 mb-4">Medication Support</h3>
            <p className="text-gray-700">
              Medication reminders, side effect management, and price comparison tools.
            </p>
          </div>
        </section>

        {/* Call to Action */}
        <section className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6">
          <Link
            to="/signup"
            className="px-8 py-4 bg-green-600 text-white rounded-lg font-semibold hover:bg-green-700"
          >
            Get Started
          </Link>
          <Link
            to="/signin"
            className="px-8 py-4 bg-white text-green-600 border border-green-600 rounded-lg font-semibold hover:bg-green-50"
          >
            Sign In
          </Link>
        </section>
      </main>

      {/* Footer */}
      <footer className="w-full bg-gray-800 text-white py-4">
        <p className="text-sm">&copy; {new Date().getFullYear()} Keep Going Care. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default LandingPage;
