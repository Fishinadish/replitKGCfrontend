// App.js
import React from 'react';
import { Routes, Route } from 'react-router-dom';
import DoctorDashboard from './components/DoctorDashboard';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import ChatBot from './components/ChatBot'
import PatientProfile from './components/PatientView';
import LandingPage from './components/LandingPage';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/signup" element={<SignUp />}/> 
        <Route path='/chatbot' element={<ChatBot />} />
        <Route path="/dashboard" element={<DoctorDashboard />} />
        <Route path="/patient-profile" element={<PatientProfile />} />
      </Routes>
    </div>
  );
}

export default App;
